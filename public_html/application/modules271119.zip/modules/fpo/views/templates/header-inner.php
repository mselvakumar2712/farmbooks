   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title><?php echo $page_title;?></title>
      <link rel="shortcut icon" href="<?php echo asset_url()?>img/fav.png">
      <!-- Bootstrap core CSS -->      
      <link rel="stylesheet" href="<?php echo asset_url()?>css/normalize.css">
      <link rel="stylesheet" href="<?php echo asset_url()?>vendor/bootstrap/css/bootstrap.min.css">
      <link href="<?php echo asset_url()?>css/font-awesome.min.css" rel="stylesheet" type="text/css">	  	   
		<!-- sidebar-->
      <link rel="stylesheet" href="<?php echo asset_url()?>css/style.css">
      <link rel="stylesheet" href="<?php echo asset_url()?>css/nav.css">
      <link rel='stylesheet' href='<?php echo asset_url()?>vendor/fontawesome/css/all.css'>
      <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
   </head>