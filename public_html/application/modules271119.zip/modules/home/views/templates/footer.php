<!-- Footer -->
      <footer class="footer">
         <div class="container">
            <div class="row">
               <div class="col-md-6 col-sm-6">
                  <a class="navbar-brand" href="#"><img src="<?php echo asset_url()?>img/home/logo.png"></a>
               </div>
               <!-- <div class="col-md-8">
               <div class="foot-nav p-l-60">
               <ul class="nav">
               <li class="nav-item">
               <a class="nav-link" href="#">About Us</a>
               </li>
               <li class="nav-item">
               <a class="nav-link" href="#">How it Works</a>
               </li>
               <li class="nav-item">
               <a class="nav-link" href="#">Whom it works</a>
               </li>
               <li class="nav-item">
               <a class="nav-link " href="#">Learn &amp; Support</a>
               </li>
               <li class="nav-item">
               <a class="nav-link " href="#">Pricing</a>
               </li>
               <li class="nav-item">
               <a class="nav-link " href="#">Contact Us</a>
               </li>
               </ul>
               </div>

               </div> -->
               <div class="ml-auto col-md-6 col-sm-6">
                  <div class="pt-4 text-right social">
                     <a href="https://www.facebook.com/farmbooks.india" target="_blank"><span class="circle"><i class="fa fa-facebook" aria-hidden="true"></i></span></a> 
                     <a href="https://twitter.com/FarmbooksI" target="_blank"><span class="circle"><i class="fa fa-twitter" aria-hidden="true"></i></span></a> 
                     <a href="https://www.linkedin.com/in/farmbooks-india-619591181/" target="_blank"><span class="circle"><i class="fa fa-linkedin" aria-hidden="true"></i></span></a> 
                  </div>
               </div>
            </div>
         </div>
         <div class=" copyright p-t-10 p-b-5 h-44">
            <div class="container">
               <div class="row">
                  <div class="col-md-6 col-sm-6">
                     <span class="f-13">Copyrights © <?php echo date("Y");?> Yesteam Solution Private Limited</span>
                  </div>
                  <div class="col-md-6 col-sm-6 text-right">
                     <span class="f-13"> Powered by <span class="text-green">Traversit Group</span></span>
                  </div>
               </div>
            </div>
         </div>
      </footer>