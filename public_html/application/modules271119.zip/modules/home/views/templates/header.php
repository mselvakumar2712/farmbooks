   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Farm Books</title>
      <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset_url()?>/fav.png">
      <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
      <link href="<?php echo asset_url()?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="<?php echo asset_url()?>css/font-awesome.min.css">
      <link rel="stylesheet" href="<?php echo asset_url()?>css/landing-style.css">
      <link rel="stylesheet" href="<?php echo asset_url()?>css/responsive.css">
      <!-- <link href="<?php echo asset_url()?>css/scrolling-nav.css" rel="stylesheet"> -->
      <!-- <script type="text/javascript" src="<?php echo asset_url()?>js/jquery-3.3.1.slim.min.js"></script>
      <script type="text/javascript" src="<?php echo asset_url()?>js/popper.min.js"></script>
      <script type="text/javascript" src="<?php echo asset_url()?>js/bootstrap.min.js"></script> -->
   </head>