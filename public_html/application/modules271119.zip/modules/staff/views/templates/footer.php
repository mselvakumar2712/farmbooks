<!-- Footer -->
       <footer>
         <div class="container-fluid">
            <div class="row mt-1">
               <div class="col-md-6 text-left textgreen">
                  <span class="copyright">Copyright &copy;<span class="text-green1"> <?php echo date("Y");?> Yesteam Solution Private Limited</span></span>
               </div>
               <div class="col-md-2 text-center textgreen">
                  <span class="copyright"></span>
               </div>
               <div class="col-md-4 text-right textgreen">
                  <span class="copyright">Powered by <a target="_blank" class="text-green1" href="http://www.traversit.net/">Traversit Group</a> </span>
               </div>
            </div>
         </div>
      </footer>      