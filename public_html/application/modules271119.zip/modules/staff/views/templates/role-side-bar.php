				<ul class="nav navbar-nav">
				  <li class="menu-item-has-children dropdown">
					<a href="<?php echo base_url('staff/role');?>" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-users"></i>Role Management</a>
                  </li>
				</ul>				             			   