<!-- Navigation -->
      <nav class="navbar navbar-expand-lg navbar-dark static-top" id="mainNav">
         <div class="container">
            <a class="mt-3" href="#page-top" style="width: 100%; margin: 0; float: none; text-align:center"><img class="img-fluid" src="<?php echo asset_url()?>img/logo.png" style="margin:auto;" alt="FPO"></a>
         </div>
      </nav>      