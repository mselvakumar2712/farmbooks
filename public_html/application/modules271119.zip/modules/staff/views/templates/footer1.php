<!-- Footer -->
       <footer>
         <div class="container-fluid">
            <div class="row mt-1">
               <div class="col-6 text-left text-success">
                  <span class="copyright"><?php echo date("Y");?> &copy; Yesteam Solution</span>
               </div>
               <div class="col-6 text-right text-success pl-0">
                  <span class="copyright">Powered by <a target="_blank" href="http://www.traversit.net/">Traversit Group</a> </span>
               </div>
            </div>
         </div>
      </footer>      