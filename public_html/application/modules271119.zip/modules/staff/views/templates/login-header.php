   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>FPO - <?php echo $page_title;?></title>
      <link rel="shortcut icon" href="<?php echo asset_url()?>fav.png">
      <!-- Bootstrap core CSS -->
      <link href="<?php echo asset_url()?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">      
      <!-- Custom styles for this template -->
      <link href="<?php echo asset_url()?>css/full-slider.css" rel="stylesheet">
      <link href="<?php echo asset_url()?>css/font-awesome.min.css" rel="stylesheet" type="text/css">
   </head>