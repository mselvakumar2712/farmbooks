				  <ul class="nav navbar-nav">
				  <li class="menu-item ">
                  <a <?php echo $page_title == 'dashboard' ? 'class="active"' : ''; ?> href="<?php echo base_url('administrator/dashboard');?>"><i class="menu-icon fa fa-dashboard"></i>Dashboard</a>
                  </li>
				  </ul>