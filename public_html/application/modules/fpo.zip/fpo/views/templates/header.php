   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title><?php echo $page_title;?></title>
      <link rel="shortcut icon" href="<?php echo asset_url()?>img/fav.png">
      <!-- Bootstrap core CSS -->
      <link href="<?php echo asset_url()?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="<?php echo asset_url()?>css/dataTables.bootstrap4.min.css" rel="stylesheet">
      <link href="<?php echo asset_url()?>css/sweetalert.min.css" rel="stylesheet">
      <!-- Custom fonts for this template -->
      <link href="<?php echo asset_url()?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

      <!-- Custom styles for this template -->
      <link href="<?php echo asset_url()?>css/main.css" rel="stylesheet">
      <!-- Custom styles for seller section -->
      <link href="<?php echo asset_url()?>css/admin.css" rel="stylesheet">
   </head>